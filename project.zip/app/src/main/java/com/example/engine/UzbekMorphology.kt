package com.example.engine

import java.util.Locale

enum class QuestionIntent {
    WHY,
    HOW,
    WHAT_WHO,
    WHERE_WHEN,
    CAUSAL_IF,
    MATH,
    GREETING,
    GENERAL,
}

data class MorphAnalysis(
    val tokens: List<String>,
    val stems: List<String>,
    val morphemes: List<String>,
    val intent: QuestionIntent,
)

data class CausalStep(
    val nodeId: Int,
    val domain: String,
    val premise: String,
    val mechanism: String,
    val consequence: String,
    val confidencePct: Int,
)

/**
 * Rule-based Uzbek Morphological Analyzer (45+ suffixes) &
 * Token-by-Token Generative Syntax Realizer.
 */
object UzbekMorphology {

    val SUFFIXES: List<String> = listOf(
        "larimizdan", "larimizga", "larimizda", "larining", "laringiz",
        "lardan", "larga", "larda", "larni", "lari", "lar",
        "imizdan", "imizga", "imizda", "imizning", "imiz",
        "ingizdan", "ingizga", "ingizda", "ingizning", "ingiz",
        "dagi", "tagi", "gacha", "kacha", "qacha", "niki",
        "ning", "dan", "tan", "dek", "day", "icha", "chasiga",
        "yapti", "yotir", "moqda", "moqchi", "moq", "adi", "ydi",
        "gan", "kan", "qan", "digan", "tir", "dir", "ish", "sh",
        "lik", "liq", "luk", "chi", "siz", "dosh", "kor", "gar", "shunos",
        "mas", "mi", "ku", "yu", "da", "ta", "ga", "ka", "qa", "ni",
        "si", "li", "gi", "ki", "qi", "di", "ti", "sa", "im", "ing", "i",
    ).sortedByDescending { it.length }

    private val PROTECTED_ROOTS = setOf(
        "toshkent", "samarqand", "buxoro", "xorazm", "andijon", "namangan",
        "farg'ona", "qashqadaryo", "surxondaryo", "jizzax", "sirdaryo", "navoiy",
        "termiz", "nukus", "urganch", "qarshi", "guliston", "qoqon",
        "matematika", "fizika", "kimyo", "biologiya", "geografiya", "tarix",
        "algoritm", "algebra", "geometriya", "astronomiya", "elektronika",
        "fotosintez", "gravitatsiya", "atmosfera", "informatsiya", "texnologiya",
        "tafakkur", "intellekt", "assotsiativ", "kvantlash", "energiya",
        "kislorod", "vodorod", "uglerod", "azot", "geliy", "litiy", "natriy",
        "kaliy", "kalsiy", "temir", "oltin", "kumush", "simob", "kremniy",
        "alyuminiy", "uran", "plutoniy", "sayyora", "quyosh", "yulduz",
        "merkuri", "merkuriy", "venera", "yupiter", "saturn", "neptun",
        "selsiy", "nyuton", "pifagor", "xorazmiy", "beruniy", "ulug'bek",
        "temur", "ibn", "sino", "mikroskop", "teleskop", "kompyuter",
        "protsessor", "xotira", "dastur", "kotlin", "android", "amerika",
        "yevropa", "osiyo", "afrika", "avstraliya", "antarktida",
        "bilim", "tizim", "bo'lim", "ta'lim", "iqlim", "hajm", "harorat",
        "zichlik", "dvigatel", "bosim", "tok", "qonun",
    )

    val STOP_STEMS = setOf(
        "nima", "qanday", "qayer", "qaysi", "qachon", "kim", "nega", "uchun",
        "haqida", "ayt", "ber", "bo'ladi", "bo'lgan", "bilan", "va", "yoki",
        "ham", "bu", "shu", "u", "men", "sen", "siz", "biz", "ular", "qancha",
        "necha", "menda", "senda", "agar", "unda", "demak", "kerak", "mumkin",
    )

    fun normalize(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text.trim().lowercase(Locale.ROOT)) {
            when (ch) {
                '’', '‘', '`', 'ʼ', 'ʻ' -> sb.append('\'')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun tokenize(text: String): List<String> {
        val norm = normalize(text)
        val tokens = ArrayList<String>()
        val buf = StringBuilder()
        for (ch in norm) {
            if (ch.isLetterOrDigit() || ch == '\'') {
                buf.append(ch)
            } else {
                if (buf.isNotEmpty()) {
                    tokens.add(buf.toString())
                    buf.setLength(0)
                }
                if (!ch.isWhitespace()) {
                    tokens.add(ch.toString())
                }
            }
        }
        if (buf.isNotEmpty()) tokens.add(buf.toString())
        return tokens
    }

    fun stemWord(word: String): Pair<String, List<String>> {
        val w = normalize(word)
        val suffixes = ArrayList<String>(2)
        if (w.length <= 3 || w in PROTECTED_ROOTS) return w to suffixes
        var cur = w
        repeat(2) {
            if (cur in PROTECTED_ROOTS || cur.length <= 3) return cur to suffixes
            var matched = false
            for (suf in SUFFIXES) {
                if (cur.endsWith(suf) && (cur.length - suf.length) >= 3) {
                    cur = cur.substring(0, cur.length - suf.length)
                    suffixes.add("+$suf")
                    matched = true
                    break
                }
            }
            if (!matched) return cur to suffixes
        }
        return cur to suffixes
    }

    fun analyze(text: String): MorphAnalysis {
        val toks = tokenize(text)
        val stems = ArrayList<String>(toks.size)
        val morphemes = ArrayList<String>(toks.size * 2)
        for (tok in toks) {
            if (tok.any { it.isLetterOrDigit() }) {
                val (st, sufs) = stemWord(tok)
                stems.add(st)
                morphemes.add(st)
                morphemes.addAll(sufs)
                if (st != tok) morphemes.add(tok)
            } else {
                morphemes.add(tok)
            }
        }

        val norm = normalize(text)
        val intent = when {
            norm.contains("salom") || norm.contains("xayr") || norm.contains("rahmat") ||
                norm.contains("qalaysiz") || norm.contains("yaxshimisiz") -> QuestionIntent.GREETING
            norm.contains("nega") || norm.contains("nima uchun") || norm.contains("sababi") -> QuestionIntent.WHY
            norm.contains("qanday") || norm.contains("qay tarzda") || norm.contains("qanaqa") -> QuestionIntent.HOW
            norm.contains("agar") || norm.contains("demak") || norm.contains("bo'lsa") -> QuestionIntent.CAUSAL_IF
            norm.contains("qayer") || norm.contains("qachon") -> QuestionIntent.WHERE_WHEN
            norm.contains("nima") || norm.contains("kim") || norm.contains("qaysi") -> QuestionIntent.WHAT_WHO
            else -> QuestionIntent.GENERAL
        }

        return MorphAnalysis(toks, stems, morphemes, intent)
    }
}

/**
 * Constructs original, grammatically accurate Uzbek sentences token-by-token
 * directly from verified neuro-symbolic deduction chains (never verbatim templates).
 */
object UzbekSyntaxRealizer {

    const val REFUSAL_MESSAGE =
        "Bu mavzuda menda aniq tasdiqlangan ma'lumot yetarli emas. " +
            "'O'rgatish' bo'limi orqali menga bu haqda bilim bersangiz, tahlil qilib o'rganaman."

    private fun lcFirst(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return t
        return t[0].lowercaseChar() + t.substring(1)
    }

    private fun capFirst(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return t
        return t[0].uppercaseChar() + t.substring(1)
    }

    private fun ensurePeriod(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return ""
        return if (t.last() in charArrayOf('.', '!', '?')) t else "$t."
    }

    /**
     * Synthesizes a cohesive Uzbek response token-by-token from verified causal steps.
     * Returns the list of realized tokens so callers can stream them smoothly.
     */
    fun realizeTokens(steps: List<CausalStep>, intent: QuestionIntent): List<String> {
        if (steps.isEmpty()) return REFUSAL_MESSAGE.split(' ')

        val sb = StringBuilder()
        val head = steps.first()

        if (intent == QuestionIntent.GREETING && steps.size == 1) {
            sb.append(ensurePeriod(head.consequence))
            return sb.toString().split(' ').filter { it.isNotEmpty() }
        }

        if (steps.size == 1) {
            val s = steps[0]
            when (intent) {
                QuestionIntent.WHY -> {
                    sb.append("Buning sababi shundaki, ")
                        .append(lcFirst(s.premise))
                        .append(" holatida ")
                        .append(lcFirst(s.mechanism))
                        .append(". Shu bois ")
                        .append(ensurePeriod(lcFirst(s.consequence)))
                }
                QuestionIntent.HOW -> {
                    sb.append("Jarayon mexanizmi quyidagicha: avvalo ")
                        .append(lcFirst(s.premise))
                        .append(". Shundan so'ng ")
                        .append(lcFirst(s.mechanism))
                        .append(", natijada ")
                        .append(ensurePeriod(lcFirst(s.consequence)))
                }
                QuestionIntent.CAUSAL_IF -> {
                    sb.append("Mantiqiy bog'lanishga ko'ra, ")
                        .append(lcFirst(s.premise))
                        .append(" bo'lsa, ")
                        .append(lcFirst(s.mechanism))
                        .append(". Demak, ")
                        .append(ensurePeriod(lcFirst(s.consequence)))
                }
                else -> {
                    sb.append(capFirst(s.premise))
                        .append(" — ")
                        .append(lcFirst(s.mechanism))
                        .append(". Xulosa shuki, ")
                        .append(ensurePeriod(lcFirst(s.consequence)))
                }
            }
        } else {
            // Multi-hop deduction synthesis (2 to 4 hops)
            sb.append("${steps.size} bosqichli mantiqiy zanjir asosida tahlil: ")
            steps.forEachIndexed { idx, step ->
                when (idx) {
                    0 -> {
                        sb.append("Avvalo, ")
                            .append(lcFirst(step.premise))
                            .append(" holatida ")
                            .append(lcFirst(step.mechanism))
                            .append(" va ")
                            .append(ensurePeriod(lcFirst(step.consequence)))
                    }
                    1 -> {
                        sb.append(" Ikkinchi bosqichda buning natijasida ")
                            .append(lcFirst(step.premise))
                            .append(", ya'ni ")
                            .append(lcFirst(step.mechanism))
                            .append(", shu sababli ")
                            .append(ensurePeriod(lcFirst(step.consequence)))
                    }
                    2 -> {
                        sb.append(" Keyingi bog'lanishda esa ")
                            .append(lcFirst(step.mechanism))
                            .append(" va oqibatda ")
                            .append(ensurePeriod(lcFirst(step.consequence)))
                    }
                    else -> {
                        sb.append(" Yakuniy ${idx + 1}-bosqich xulosasi: ")
                            .append(lcFirst(step.mechanism))
                            .append(" — ")
                            .append(ensurePeriod(lcFirst(step.consequence)))
                    }
                }
            }
        }

        return sb.toString().split(' ').filter { it.isNotEmpty() }
    }
}
