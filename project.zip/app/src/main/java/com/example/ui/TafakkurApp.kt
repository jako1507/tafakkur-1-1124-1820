package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary

@Composable
fun TafakkurApp(
    viewModel: TafakkurViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    BackHandler(enabled = state.activeTab != AppTab.SUHBAT) {
        viewModel.selectTab(AppTab.SUHBAT)
    }

    if (state.showRamExpansionDialog) {
        val nextBudget = (state.telemetry.ramBudgetMb + 64).coerceAtMost(state.telemetry.maxRamCeilingMb)
        AlertDialog(
            onDismissRequest = viewModel::denyRamExpansionAndPrune,
            containerColor = MaterialTheme.colorScheme.surface,
            title = {
                Text(
                    text = "Xotirani kengaytirish ruxsati",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            },
            text = {
                Text(
                    text = "Tafakkur tarmog'i kengaymoqda. Chuqurroq fikrlash uchun qo'shimcha +64 MB RAM talab etiladi (Jami: $nextBudget / ${state.telemetry.maxRamCeilingMb} MB). Ruxsat berasizmi?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            },
            confirmButton = {
                Button(
                    onClick = viewModel::grantRamExpansion,
                    modifier = Modifier.testTag("grant_ram_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                ) {
                    Text("Ruxsat berish (+64 MB)")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = viewModel::denyRamExpansionAndPrune,
                    modifier = Modifier.testTag("deny_ram_button"),
                ) {
                    Text("Rad etish (Xotirani siqish)")
                }
            },
        )
    }

    val bgColor = MaterialTheme.colorScheme.background

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .drawBehind {
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            EmeraldPrimary.copy(alpha = 0.14f),
                            Color.Transparent,
                        ),
                        center = Offset(size.width * 0.18f, size.height * 0.08f),
                        radius = size.maxDimension * 0.55f,
                    )
                )
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            CyanSecondary.copy(alpha = 0.10f),
                            Color.Transparent,
                        ),
                        center = Offset(size.width * 0.88f, size.height * 0.25f),
                        radius = size.maxDimension * 0.50f,
                    )
                )
            },
    ) {
        val useRail = maxWidth >= 600.dp

        if (useRail) {
            Row(modifier = Modifier.fillMaxSize()) {
                TafakkurNavRail(
                    activeTab = state.activeTab,
                    onSelect = viewModel::selectTab,
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .navigationBarsPadding(),
                ) {
                    TabContent(state = state, viewModel = viewModel)
                }
            }
        } else {
            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    TafakkurBottomBar(
                        activeTab = state.activeTab,
                        onSelect = viewModel::selectTab,
                    )
                },
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .padding(innerPadding),
                ) {
                    TabContent(state = state, viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
private fun TabContent(
    state: TafakkurUiState,
    viewModel: TafakkurViewModel,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    when (state.activeTab) {
        AppTab.SUHBAT -> ChatScreen(
            state = state,
            onInputChange = viewModel::updateInputDraft,
            onSend = viewModel::sendMessage,
            onFeedback = viewModel::submitFeedback,
            onClearChat = viewModel::clearChat,
        )
        AppTab.ORGATISH -> TrainScreen(
            state = state,
            onTopicChange = viewModel::updateTrainTopic,
            onTextChange = viewModel::updateTrainText,
            onRunCausalTrain = viewModel::runCausalTraining,
            onImportTxtUri = { uri -> viewModel.importTxtFromUri(context, uri) },
            onRunDeepSynthesis = viewModel::runDeepLogicalSynthesis,
            onDeleteRule = viewModel::deleteUserRule,
            onTestRule = viewModel::testRuleInChat,
        )
        AppTab.DVIGATEL -> MonitorScreen(
            state = state,
            onRefresh = viewModel::refreshTelemetry,
            onRunBenchmark = viewModel::runBenchmark,
            onRequestRamExpansion = viewModel::requestRamExpansionDialog,
        )
    }
}

@Composable
private fun TafakkurBottomBar(
    activeTab: AppTab,
    onSelect: (AppTab) -> Unit,
) {
    NavigationBar(
        modifier = Modifier.navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
    ) {
        val navColors = NavigationBarItemDefaults.colors(
            selectedIconColor = EmeraldPrimary,
            selectedTextColor = EmeraldPrimary,
            indicatorColor = EmeraldPrimary.copy(alpha = 0.16f),
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        NavigationBarItem(
            selected = activeTab == AppTab.SUHBAT,
            onClick = { onSelect(AppTab.SUHBAT) },
            modifier = Modifier.testTag("tab_suhbat"),
            colors = navColors,
            icon = {
                Icon(
                    imageVector = if (activeTab == AppTab.SUHBAT) Icons.Rounded.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                    contentDescription = stringResource(R.string.nav_chat),
                )
            },
            label = { Text(stringResource(R.string.nav_chat)) },
        )
        NavigationBarItem(
            selected = activeTab == AppTab.ORGATISH,
            onClick = { onSelect(AppTab.ORGATISH) },
            modifier = Modifier.testTag("tab_orgatish"),
            colors = navColors,
            icon = {
                Icon(
                    imageVector = if (activeTab == AppTab.ORGATISH) Icons.Rounded.Psychology else Icons.Outlined.Psychology,
                    contentDescription = stringResource(R.string.nav_train),
                )
            },
            label = { Text(stringResource(R.string.nav_train_short)) },
        )
        NavigationBarItem(
            selected = activeTab == AppTab.DVIGATEL,
            onClick = { onSelect(AppTab.DVIGATEL) },
            modifier = Modifier.testTag("tab_dvigatel"),
            colors = navColors,
            icon = {
                Icon(
                    imageVector = if (activeTab == AppTab.DVIGATEL) Icons.Rounded.Memory else Icons.Outlined.Memory,
                    contentDescription = stringResource(R.string.nav_monitor),
                )
            },
            label = { Text(stringResource(R.string.nav_monitor_short)) },
        )
    }
}

@Composable
private fun TafakkurNavRail(
    activeTab: AppTab,
    onSelect: (AppTab) -> Unit,
) {
    NavigationRail(
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
    ) {
        val railColors = NavigationRailItemDefaults.colors(
            selectedIconColor = EmeraldPrimary,
            selectedTextColor = EmeraldPrimary,
            indicatorColor = EmeraldPrimary.copy(alpha = 0.16f),
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        NavigationRailItem(
            selected = activeTab == AppTab.SUHBAT,
            onClick = { onSelect(AppTab.SUHBAT) },
            modifier = Modifier.testTag("rail_suhbat"),
            colors = railColors,
            icon = {
                Icon(
                    imageVector = if (activeTab == AppTab.SUHBAT) Icons.Rounded.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                    contentDescription = stringResource(R.string.nav_chat),
                )
            },
            label = { Text(stringResource(R.string.nav_chat)) },
        )
        NavigationRailItem(
            selected = activeTab == AppTab.ORGATISH,
            onClick = { onSelect(AppTab.ORGATISH) },
            modifier = Modifier.testTag("rail_orgatish"),
            colors = railColors,
            icon = {
                Icon(
                    imageVector = if (activeTab == AppTab.ORGATISH) Icons.Rounded.Psychology else Icons.Outlined.Psychology,
                    contentDescription = stringResource(R.string.nav_train),
                )
            },
            label = { Text(stringResource(R.string.nav_train_short)) },
        )
        NavigationRailItem(
            selected = activeTab == AppTab.DVIGATEL,
            onClick = { onSelect(AppTab.DVIGATEL) },
            modifier = Modifier.testTag("rail_dvigatel"),
            colors = railColors,
            icon = {
                Icon(
                    imageVector = if (activeTab == AppTab.DVIGATEL) Icons.Rounded.Memory else Icons.Outlined.Memory,
                    contentDescription = stringResource(R.string.nav_monitor),
                )
            },
            label = { Text(stringResource(R.string.nav_monitor_short)) },
        )
    }
}
