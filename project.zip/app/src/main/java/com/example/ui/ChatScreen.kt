package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.OfflineBolt
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.engine.ReasoningTrace
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorCoral
import java.util.Locale

private val QUICK_PROMPTS = listOf(
    "Nega suv muzlaganda muz suvda suzadi?",
    "Al-Xorazmiy kim bo'lgan?",
    "O'zbekistonning poytaxti qayerda?",
    "1.58-bit uchlik dvigatel qanday ishlaydi?",
    "245 + 378",
    "Marsdagi ko'k filning narxi qancha?",
)

@Composable
fun ChatScreen(
    state: TafakkurUiState,
    onInputChange: (String) -> Unit,
    onSend: (String?) -> Unit,
    onFeedback: (Long, Boolean) -> Unit,
    onClearChat: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()

    LaunchedEffect(state.messages.size, state.messages.lastOrNull()?.text) {
        if (state.messages.isNotEmpty()) {
            listState.animateScrollToItem(state.messages.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ChatHeaderBar(
            state = state,
            onClearChat = onClearChat,
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxWidth(),
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .widthIn(max = 720.dp)
                .fillMaxWidth(),
        ) {
            if (state.messages.isEmpty()) {
                WelcomeHeroPane(
                    onPromptSelected = { prompt -> onSend(prompt) },
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(state.messages, key = { it.id }) { msg ->
                        ChatBubble(
                            message = msg,
                            onFeedback = { positive -> onFeedback(msg.id, positive) },
                        )
                    }
                }
            }
        }

        ChatComposerBar(
            draft = state.inputDraft,
            isGenerating = state.isGenerating,
            onInputChange = onInputChange,
            onSend = { onSend(null) },
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxWidth(),
        )
    }
}

@Composable
private fun ChatHeaderBar(
    state: TafakkurUiState,
    onClearChat: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = state.telemetry
    val speedLabel = if (t.lastTokensPerSec > 0.0) {
        String.format(Locale.US, "Tezlik: %.0f token/soniya", t.lastTokensPerSec)
    } else {
        "Tezlik: tayyor (<1 ms/token)"
    }
    val ramLabel = String.format(Locale.US, "Xotira: %.1f / %d MB", t.ramUsageMb, t.ramBudgetMb)

    Surface(
        modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    TernaryPulseEmblem(modifier = Modifier.size(34.dp))
                    Column {
                        Text(
                            text = "Tafakkur — ${stringResource(R.string.nav_chat)}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = "${stringResource(R.string.offline_badge)} • ${t.maxAllowedHops}-bosqich",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary,
                        )
                    }
                }

                if (state.messages.isNotEmpty()) {
                    IconButton(
                        onClick = onClearChat,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("clear_chat_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.DeleteOutline,
                            contentDescription = stringResource(R.string.clear_chat),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                TelemetryPill(
                    icon = Icons.Rounded.Speed,
                    text = speedLabel,
                    accent = CyanSecondary,
                    modifier = Modifier.weight(1f),
                )
                TelemetryPill(
                    icon = Icons.Rounded.Memory,
                    text = ramLabel,
                    accent = EmeraldPrimary,
                )
            }
        }
    }
}

@Composable
private fun TelemetryPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(accent.copy(alpha = 0.11f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(14.dp),
        )
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun TernaryPulseEmblem(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val alpha by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulseAlpha",
    )

    Canvas(modifier = modifier) {
        val r = size.minDimension / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(EmeraldPrimary.copy(alpha = 0.35f * alpha), Color.Transparent)
            ),
            radius = r,
            center = c,
        )
        drawCircle(
            color = CyanSecondary.copy(alpha = 0.85f),
            radius = r * 0.72f,
            center = c,
            style = Stroke(width = 2.5f),
        )
        drawCircle(color = AmberTertiary, radius = r * 0.14f, center = Offset(c.x - r * 0.32f, c.y + r * 0.12f))
        drawCircle(color = CyanSecondary, radius = r * 0.14f, center = Offset(c.x, c.y - r * 0.30f))
        drawCircle(color = EmeraldPrimary, radius = r * 0.14f, center = Offset(c.x + r * 0.32f, c.y + r * 0.12f))
    }
}

@Composable
private fun WelcomeHeroPane(
    onPromptSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.OfflineBolt,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(22.dp),
                        )
                        Text(
                            text = stringResource(R.string.welcome_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Text(
                        text = stringResource(R.string.welcome_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TernaryTritChip(label = "-1", color = AmberTertiary)
                        TernaryTritChip(label = "0", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TernaryTritChip(label = "+1", color = EmeraldPrimary)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = "4096-bit POPCNT • Chegara >=65%",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanSecondary,
                            modifier = Modifier.align(Alignment.CenterVertically),
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Mantiqiy sinov savollari:",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
        }

        items(QUICK_PROMPTS) { prompt ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onPromptSelected(prompt) }
                    .testTag("quick_prompt_item"),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = CyanSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun TernaryTritChip(label: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = color,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun ChatBubble(
    message: ChatMessage,
    onFeedback: (Boolean) -> Unit,
) {
    val isUser = message.isUser
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // Collapsible "Ichki Tafakkur (Fikrlash jarayoni)" Card above every AI reply
        if (!isUser && message.trace != null) {
            IchkiTafakkurCard(
                trace = message.trace,
                modifier = Modifier.widthIn(max = 540.dp),
            )
        }

        Surface(
            modifier = Modifier.widthIn(max = 540.dp),
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (isUser) 20.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 20.dp,
            ),
            color = if (isUser) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surface
            },
            border = BorderStroke(
                1.dp,
                if (isUser) EmeraldPrimary.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outline,
            ),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (!isUser) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        message.isStreaming -> CyanSecondary
                                        message.confidencePct < 65 -> AmberTertiary
                                        else -> EmeraldPrimary
                                    }
                                )
                        )
                        Text(
                            text = if (message.isStreaming) {
                                "Tafakkur fikrlamoqda..."
                            } else {
                                "Tafakkur 4096-bit • Ishonch: ${message.confidencePct}%"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (message.confidencePct < 65 && !message.isStreaming) AmberTertiary else CyanSecondary,
                        )
                    }
                }

                Text(
                    text = if (message.text.isEmpty() && message.isStreaming) "..." else message.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )

                AnimatedVisibility(visible = !isUser && !message.isStreaming && message.tokenCount > 0) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "%d token • %.3f ms/tok • %.0f tok/s • %d bosqich",
                                    message.tokenCount,
                                    message.msPerToken,
                                    message.tokensPerSec,
                                    message.trace?.maxHopsUsed ?: 1,
                                ),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        // Self-Evolving Feedback Buttons (👍 To'g'ri / 👎 Noto'g'ri)
                        if (!message.trace?.verifiedChainNodeIds.isNullOrEmpty()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                FeedbackChipButton(
                                    label = "To'g'ri",
                                    selected = message.vote == FeedbackVote.POSITIVE,
                                    icon = if (message.vote == FeedbackVote.POSITIVE) Icons.Rounded.ThumbUp else Icons.Outlined.ThumbUp,
                                    accent = EmeraldPrimary,
                                    onClick = { onFeedback(true) },
                                    testTag = "vote_positive_button",
                                )
                                FeedbackChipButton(
                                    label = "Noto'g'ri",
                                    selected = message.vote == FeedbackVote.NEGATIVE,
                                    icon = if (message.vote == FeedbackVote.NEGATIVE) Icons.Rounded.ThumbDown else Icons.Outlined.ThumbDown,
                                    accent = ErrorCoral,
                                    onClick = { onFeedback(false) },
                                    testTag = "vote_negative_button",
                                )
                            }
                            if (message.feedbackNote != null) {
                                Text(
                                    text = message.feedbackNote,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldPrimary,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IchkiTafakkurCard(
    trace: ReasoningTrace,
    modifier: Modifier = Modifier,
) {
    var expanded by rememberSaveable { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { expanded = !expanded }
            .testTag("ichki_tafakkur_card"),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, CyanSecondary.copy(alpha = 0.35f)),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Psychology,
                        contentDescription = null,
                        tint = CyanSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        text = "Ichki Tafakkur (${trace.branches.size} yo'l, ${trace.prunedCount} bekor)",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyanSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = if (expanded) "Yig'ish" else "Yoyish",
                    tint = CyanSecondary,
                    modifier = Modifier.size(20.dp),
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    trace.steps.forEach { stepText ->
                        Text(
                            text = stepText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    trace.branches.forEach { b ->
                        val bColor = if (b.pruned) AmberTertiary else EmeraldPrimary
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = bColor.copy(alpha = 0.10f),
                            border = BorderStroke(1.dp, bColor.copy(alpha = 0.35f)),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                            ) {
                                Text(
                                    text = "${b.branchNumber}-yo'l (${b.domain}): ${b.statusText}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = bColor,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = b.summary,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedbackChipButton(
    label: String,
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    onClick: () -> Unit,
    testTag: String,
) {
    Surface(
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) accent.copy(alpha = 0.22f) else accent.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, accent.copy(alpha = if (selected) 0.9f else 0.35f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accent,
                modifier = Modifier.size(16.dp),
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = accent,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

@Composable
private fun ChatComposerBar(
    draft: String,
    isGenerating: Boolean,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = onInputChange,
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                placeholder = {
                    Text(
                        text = stringResource(R.string.input_placeholder),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                },
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { if (!isGenerating) onSend() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                ),
            )

            val canSend = draft.isNotBlank() && !isGenerating
            Surface(
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(enabled = canSend, onClick = onSend)
                    .testTag("send_button"),
                shape = RoundedCornerShape(16.dp),
                color = if (canSend) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = stringResource(R.string.send_button),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Send,
                        contentDescription = stringResource(R.string.send_button),
                        tint = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }
    }
}
