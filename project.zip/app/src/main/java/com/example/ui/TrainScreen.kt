package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.engine.KnowledgeNode
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorCoral
import java.util.Locale

@Composable
fun TrainScreen(
    state: TafakkurUiState,
    onTopicChange: (String) -> Unit,
    onTextChange: (String) -> Unit,
    onRunCausalTrain: () -> Unit,
    onImportTxtUri: (Uri) -> Unit,
    onRunDeepSynthesis: () -> Unit,
    onDeleteRule: (Int) -> Unit,
    onTestRule: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val txtPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri != null) {
            onImportTxtUri(uri)
        }
    }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Psychology,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(28.dp),
                        )
                        Text(
                            text = stringResource(R.string.train_title),
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                    }
                    Text(
                        text = stringResource(R.string.train_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        OutlinedTextField(
                            value = state.trainTopic,
                            onValueChange = onTopicChange,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("train_topic_input"),
                            label = { Text(stringResource(R.string.train_question_label)) },
                            placeholder = { Text(stringResource(R.string.train_question_hint)) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                        )

                        OutlinedTextField(
                            value = state.trainText,
                            onValueChange = onTextChange,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("train_text_input"),
                            label = { Text(stringResource(R.string.train_answer_label)) },
                            placeholder = { Text(stringResource(R.string.train_answer_hint)) },
                            minLines = 4,
                            maxLines = 8,
                            shape = RoundedCornerShape(14.dp),
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Button(
                                onClick = onRunCausalTrain,
                                enabled = state.trainText.trim().length >= 6 && !state.isTraining,
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("train_submit_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldPrimary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary,
                                ),
                            ) {
                                if (state.isTraining) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoFixHigh,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = stringResource(R.string.train_submit),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                            }

                            OutlinedButton(
                                onClick = { txtPicker.launch(arrayOf("text/plain", "text/*")) },
                                enabled = !state.isTraining,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("import_txt_button"),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, CyanSecondary.copy(alpha = 0.7f)),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.UploadFile,
                                    contentDescription = stringResource(R.string.train_import_txt),
                                    tint = CyanSecondary,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = stringResource(R.string.train_import_txt),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CyanSecondary,
                                )
                            }
                        }

                        // Deep Logical Synthesis Button ("Chuqur mantiqiy sintez")
                        OutlinedButton(
                            onClick = onRunDeepSynthesis,
                            enabled = !state.isTraining,
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("deep_synthesis_button"),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, AmberTertiary.copy(alpha = 0.7f)),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Hub,
                                contentDescription = null,
                                tint = AmberTertiary,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.size(8.dp))
                            Text(
                                text = "${stringResource(R.string.train_deep_synthesis)} (A→B + B→C ⇒ A→C)",
                                style = MaterialTheme.typography.labelMedium,
                                color = AmberTertiary,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }

            // Self-Play Verification Report
            if (state.selfPlayReport != null) {
                item {
                    val rep = state.selfPlayReport
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = EmeraldPrimary.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.45f)),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = EmeraldPrimary,
                                )
                                Text(
                                    text = String.format(
                                        Locale.US,
                                        "Self-Play yakuni: %d qoida ajratildi • %d/%d sinov o'tdi (%d%%) • %.2f ms",
                                        rep.extractedRulesCount,
                                        rep.selfPlayPassed,
                                        rep.selfPlayTotal,
                                        rep.avgConfidencePct,
                                        rep.elapsedMs,
                                    ),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            rep.logs.take(8).forEach { logLine ->
                                Text(
                                    text = "• $logLine",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    }
                }
            }

            // Deep Logical Synthesis Report
            if (state.synthesisReport != null) {
                item {
                    val syn = state.synthesisReport
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = AmberTertiary.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, AmberTertiary.copy(alpha = 0.45f)),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "Chuqur sintez: %d ta yangi qoida, %d ta bog'lanish (%.2f ms)",
                                    syn.newRulesSynthesized,
                                    syn.newLinksConnected,
                                    syn.elapsedMs,
                                ),
                                style = MaterialTheme.typography.labelMedium,
                                color = AmberTertiary,
                                fontWeight = FontWeight.Bold,
                            )
                            if (syn.examples.isEmpty()) {
                                Text(
                                    text = "Mavjud bilimlar bo'yicha barcha tranzitiv bog'lanishlar allaqachon sintez qilingan.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            } else {
                                syn.examples.forEach { ex ->
                                    Text(
                                        text = "• $ex",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = stringResource(R.string.train_learned_header),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = "${state.userRules.size} ta qoida",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyanSecondary,
                    )
                }
            }

            if (state.userRules.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.65f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    ) {
                        Text(
                            text = stringResource(R.string.train_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(18.dp),
                        )
                    }
                }
            } else {
                items(state.userRules, key = { it.id }) { rule ->
                    LearnedCausalRuleCard(
                        rule = rule,
                        onTest = { onTestRule("${rule.premise}?") },
                        onDelete = { onDeleteRule(rule.id) },
                    )
                }
            }
        }
    }
}

@Composable
private fun LearnedCausalRuleCard(
    rule: KnowledgeNode,
    onTest: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = rule.domain,
                    style = MaterialTheme.typography.labelSmall,
                    color = AmberTertiary,
                )
                Text(
                    text = "Vazn: ${rule.weight}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldPrimary,
                )
            }
            Text(
                text = "Agar: ${rule.premise}",
                style = MaterialTheme.typography.titleMedium,
                color = CyanSecondary,
            )
            Text(
                text = "Unda: ${rule.consequence}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedButton(
                    onClick = onTest,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("test_learned_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.6f)),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = "Suhbatda sinash",
                        style = MaterialTheme.typography.labelMedium,
                        color = EmeraldPrimary,
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("delete_learned_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = "O'chirish",
                        tint = ErrorCoral,
                    )
                }
            }
        }
    }
}
