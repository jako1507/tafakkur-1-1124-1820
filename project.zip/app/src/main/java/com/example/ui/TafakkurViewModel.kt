package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.BenchmarkItem
import com.example.engine.EngineTelemetry
import com.example.engine.KnowledgeNode
import com.example.engine.ReasoningTrace
import com.example.engine.SelfPlayReport
import com.example.engine.SynthesisReport
import com.example.engine.TernaryEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppTab {
    SUHBAT,
    ORGATISH,
    DVIGATEL,
}

enum class FeedbackVote {
    NONE,
    POSITIVE,
    NEGATIVE,
}

data class ChatMessage(
    val id: Long,
    val isUser: Boolean,
    val promptForRetry: String = "",
    val text: String,
    val tokenCount: Int = 0,
    val tokensPerSec: Double = 0.0,
    val msPerToken: Double = 0.0,
    val confidencePct: Int = 0,
    val trace: ReasoningTrace? = null,
    val isStreaming: Boolean = false,
    val vote: FeedbackVote = FeedbackVote.NONE,
    val feedbackNote: String? = null,
)

data class TafakkurUiState(
    val activeTab: AppTab = AppTab.SUHBAT,
    val messages: List<ChatMessage> = emptyList(),
    val inputDraft: String = "",
    val isGenerating: Boolean = false,
    val trainTopic: String = "",
    val trainText: String = "",
    val isTraining: Boolean = false,
    val selfPlayReport: SelfPlayReport? = null,
    val synthesisReport: SynthesisReport? = null,
    val userRules: List<KnowledgeNode> = emptyList(),
    val telemetry: EngineTelemetry = EngineTelemetry(),
    val benchmarkResults: List<BenchmarkItem> = emptyList(),
    val isBenchmarkRunning: Boolean = false,
    val showRamExpansionDialog: Boolean = false,
    val ramStatusBanner: String? = null,
)

class TafakkurViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = TernaryEngine(application.applicationContext)

    private val _uiState = MutableStateFlow(
        TafakkurUiState(
            userRules = engine.getUserNodes(),
            telemetry = engine.getTelemetry(),
        )
    )
    val uiState: StateFlow<TafakkurUiState> = _uiState.asStateFlow()

    private var generationJob: Job? = null

    fun selectTab(tab: AppTab) {
        _uiState.update {
            it.copy(
                activeTab = tab,
                telemetry = engine.getTelemetry(),
                userRules = engine.getUserNodes(),
            )
        }
    }

    fun updateInputDraft(text: String) {
        _uiState.update { it.copy(inputDraft = text) }
    }

    fun sendMessage(overridePrompt: String? = null) {
        val rawPrompt = (overridePrompt ?: _uiState.value.inputDraft).trim()
        if (rawPrompt.isEmpty() || _uiState.value.isGenerating) return

        val userMsg = ChatMessage(
            id = System.nanoTime(),
            isUser = true,
            text = rawPrompt,
        )
        val botMsgId = System.nanoTime() + 1L
        val botPlaceholder = ChatMessage(
            id = botMsgId,
            isUser = false,
            promptForRetry = rawPrompt,
            text = "",
            isStreaming = true,
        )

        _uiState.update {
            it.copy(
                messages = it.messages + userMsg + botPlaceholder,
                inputDraft = if (overridePrompt == null) "" else it.inputDraft,
                isGenerating = true,
                activeTab = AppTab.SUHBAT,
            )
        }

        launchGeneration(botMsgId, rawPrompt, emptySet())
    }

    private fun launchGeneration(
        botMsgId: Long,
        prompt: String,
        excludedRootIds: Set<Int>,
    ) {
        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            engine.generateStream(prompt, excludedRootIds).collect { chunk ->
                _uiState.update { state ->
                    val updated = state.messages.map { msg ->
                        if (msg.id == botMsgId) {
                            msg.copy(
                                text = chunk.partialText,
                                tokenCount = chunk.tokenCount,
                                tokensPerSec = chunk.tokensPerSec,
                                msPerToken = chunk.msPerToken,
                                confidencePct = chunk.confidencePct,
                                trace = chunk.trace,
                                isStreaming = !chunk.isFinished,
                            )
                        } else {
                            msg
                        }
                    }
                    state.copy(
                        messages = updated,
                        isGenerating = !chunk.isFinished,
                        telemetry = if (chunk.isFinished) engine.getTelemetry() else state.telemetry,
                    )
                }
            }
        }
    }

    fun submitFeedback(messageId: Long, positive: Boolean) {
        val targetMsg = _uiState.value.messages.find { it.id == messageId } ?: return
        if (targetMsg.isUser || targetMsg.isStreaming) return
        val nodeIds = targetMsg.trace?.verifiedChainNodeIds.orEmpty()

        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                engine.applyFeedback(nodeIds, positive)
            }
            if (positive) {
                _uiState.update { state ->
                    state.copy(
                        messages = state.messages.map { m ->
                            if (m.id == messageId) {
                                m.copy(
                                    vote = FeedbackVote.POSITIVE,
                                    feedbackNote = "Yo'nalish mustahkamlandi (+10 uchlik vazn)",
                                )
                            } else m
                        },
                        telemetry = engine.getTelemetry(),
                    )
                }
            } else {
                // Rewire: exclude rejected root node and search alternative verified reasoning branch
                val rejectedRoot = nodeIds.firstOrNull()
                val rewireId = System.nanoTime()
                val rewirePlaceholder = ChatMessage(
                    id = rewireId,
                    isUser = false,
                    promptForRetry = targetMsg.promptForRetry,
                    text = "",
                    isStreaming = true,
                )
                _uiState.update { state ->
                    val marked = state.messages.map { m ->
                        if (m.id == messageId) {
                            m.copy(
                                vote = FeedbackVote.NEGATIVE,
                                feedbackNote = "Yo'l zaiflashtirildi — muqobil mantiqiy tarmoq qidirilmoqda...",
                            )
                        } else m
                    }
                    state.copy(
                        messages = marked + rewirePlaceholder,
                        isGenerating = true,
                    )
                }
                val excluded = if (rejectedRoot != null) setOf(rejectedRoot) else emptySet()
                launchGeneration(rewireId, targetMsg.promptForRetry, excluded)
            }
        }
    }

    fun clearChat() {
        generationJob?.cancel()
        _uiState.update {
            it.copy(
                messages = emptyList(),
                isGenerating = false,
                telemetry = engine.getTelemetry(),
            )
        }
    }

    fun updateTrainTopic(topic: String) {
        _uiState.update { it.copy(trainTopic = topic) }
    }

    fun updateTrainText(text: String) {
        _uiState.update { it.copy(trainText = text) }
    }

    fun runCausalTraining() {
        val text = _uiState.value.trainText.trim()
        val topic = _uiState.value.trainTopic.trim()
        if (text.length < 6 || _uiState.value.isTraining) return

        _uiState.update { it.copy(isTraining = true, selfPlayReport = null) }
        viewModelScope.launch {
            val report = withContext(Dispatchers.Default) {
                engine.trainFromTextWithSelfPlay(topic, text)
            }
            _uiState.update {
                it.copy(
                    isTraining = false,
                    trainTopic = "",
                    trainText = "",
                    selfPlayReport = report,
                    userRules = engine.getUserNodes(),
                    telemetry = engine.getTelemetry(),
                    showRamExpansionDialog = report.ramExpansionRequired,
                )
            }
        }
    }

    fun importTxtFromUri(context: Context, uri: Uri) {
        if (_uiState.value.isTraining) return
        viewModelScope.launch {
            val content = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                    it.readText()
                }.orEmpty()
            }
            if (content.isNotBlank()) {
                _uiState.update { it.copy(trainText = content.take(12000), isTraining = true) }
                val report = withContext(Dispatchers.Default) {
                    engine.trainFromTextWithSelfPlay("Fayldan yuklangan bilim", content.take(12000))
                }
                _uiState.update {
                    it.copy(
                        isTraining = false,
                        trainText = "",
                        selfPlayReport = report,
                        userRules = engine.getUserNodes(),
                        telemetry = engine.getTelemetry(),
                        showRamExpansionDialog = report.ramExpansionRequired,
                    )
                }
            }
        }
    }

    fun runDeepLogicalSynthesis() {
        if (_uiState.value.isTraining) return
        _uiState.update { it.copy(isTraining = true) }
        viewModelScope.launch {
            val report = withContext(Dispatchers.Default) {
                engine.runDeepLogicalSynthesis()
            }
            _uiState.update {
                it.copy(
                    isTraining = false,
                    synthesisReport = report,
                    userRules = engine.getUserNodes(),
                    telemetry = engine.getTelemetry(),
                    showRamExpansionDialog = report.ramExpansionRequired,
                )
            }
        }
    }

    fun deleteUserRule(nodeId: Int) {
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                engine.deleteUserNode(nodeId)
            }
            _uiState.update {
                it.copy(
                    userRules = engine.getUserNodes(),
                    telemetry = engine.getTelemetry(),
                )
            }
        }
    }

    fun testRuleInChat(query: String) {
        sendMessage(overridePrompt = query)
    }

    fun requestRamExpansionDialog() {
        _uiState.update { it.copy(showRamExpansionDialog = true) }
    }

    fun grantRamExpansion() {
        val newBudget = engine.grantRamExpansion()
        _uiState.update {
            it.copy(
                showRamExpansionDialog = false,
                telemetry = engine.getTelemetry(),
                ramStatusBanner = "RAM chegarasi $newBudget MB ga kengaytirildi — 4-bosqichli chuqur mantiqiy tafakkur faollashtirildi!",
            )
        }
    }

    fun denyRamExpansionAndPrune() {
        val pruned = engine.denyRamExpansionAndPrune()
        _uiState.update {
            it.copy(
                showRamExpansionDialog = false,
                userRules = engine.getUserNodes(),
                telemetry = engine.getTelemetry(),
                ramStatusBanner = "Xotira siqildi: $pruned ta kuchsiz tugun tozalandi, joriy byudjet saqlandi.",
            )
        }
    }

    fun refreshTelemetry() {
        _uiState.update { it.copy(telemetry = engine.getTelemetry(), ramStatusBanner = null) }
    }

    fun runBenchmark() {
        if (_uiState.value.isBenchmarkRunning) return
        _uiState.update { it.copy(isBenchmarkRunning = true) }
        viewModelScope.launch {
            val results = withContext(Dispatchers.Default) {
                engine.runUzbekReasoningBenchmark()
            }
            _uiState.update {
                it.copy(
                    benchmarkResults = results,
                    isBenchmarkRunning = false,
                    telemetry = engine.getTelemetry(),
                )
            }
        }
    }
}
