package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = OnEmerald,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = TextPrimary,
    secondary = CyanSecondary,
    onSecondary = OnCyan,
    secondaryContainer = CyanContainer,
    onSecondaryContainer = TextPrimary,
    tertiary = AmberTertiary,
    tertiaryContainer = AmberContainer,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = SlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurfaceHigh,
    onSurfaceVariant = TextSecondary,
    outline = SlateBorder,
    error = ErrorCoral,
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldLightPrimary,
    onPrimary = LightSurface,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = TextPrimary,
    secondary = CyanLightSecondary,
    onSecondary = LightSurface,
    secondaryContainer = LightSurfaceHigh,
    onSecondaryContainer = TextDarkPrimary,
    tertiary = AmberTertiary,
    background = LightBg,
    onBackground = TextDarkPrimary,
    surface = LightSurface,
    onSurface = TextDarkPrimary,
    surfaceVariant = LightSurfaceHigh,
    onSurfaceVariant = TextDarkSecondary,
    outline = LightBorder,
    error = ErrorCoral,
)

val TafakkurShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun TafakkurTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = TafakkurTypography,
        shapes = TafakkurShapes,
        content = content,
    )
}
