package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Bioluminescent Emerald-Cyan Compute Lab Palette
val ObsidianBg = Color(0xFF071016)
val SlateSurface = Color(0xFF0E1B24)
val SlateSurfaceHigh = Color(0xFF152734)
val SlateBorder = Color(0xFF213B4D)

val EmeraldPrimary = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF0A3A2C)
val OnEmerald = Color(0xFF021F16)

val CyanSecondary = Color(0xFF22D3EE)
val CyanContainer = Color(0xFF0B3642)
val OnCyan = Color(0xFF041E24)

val AmberTertiary = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF3E2908)

val TextPrimary = Color(0xFFEBF4F8)
val TextSecondary = Color(0xFF94AEB9)
val ErrorCoral = Color(0xFFF87171)

// Clean High-Contrast Light Palette
val LightBg = Color(0xFFF3F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFE4EFF4)
val LightBorder = Color(0xFFC5DCE6)
val EmeraldLightPrimary = Color(0xFF059669)
val CyanLightSecondary = Color(0xFF0891B2)
val TextDarkPrimary = Color(0xFF0B1922)
val TextDarkSecondary = Color(0xFF476370)
