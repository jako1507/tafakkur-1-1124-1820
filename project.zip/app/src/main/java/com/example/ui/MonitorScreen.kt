package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import java.util.Locale

@Composable
fun MonitorScreen(
    state: TafakkurUiState,
    onRefresh: () -> Unit,
    onRunBenchmark: () -> Unit,
    onRequestRamExpansion: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = state.telemetry
    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.monitor_title),
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        Text(
                            text = stringResource(R.string.monitor_subtitle),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("refresh_telemetry_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Yangilash",
                            tint = CyanSecondary,
                        )
                    }
                }
            }

            item {
                AnimatedVisibility(visible = state.ramStatusBanner != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = EmeraldPrimary.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.45f)),
                    ) {
                        Text(
                            text = state.ramStatusBanner.orEmpty(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(14.dp),
                        )
                    }
                }
            }

            // Primary Speed & Dynamic RAM Telemetry Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    MetricCard(
                        title = "Tezlik",
                        value = if (t.lastTokensPerSec > 0.0) {
                            String.format(Locale.US, "%.0f token/soniya", t.lastTokensPerSec)
                        } else {
                            "Tayyor"
                        },
                        subtitle = if (t.lastMsPerToken > 0.0) {
                            String.format(Locale.US, "%.3f ms / token", t.lastMsPerToken)
                        } else {
                            "< 1.0 ms / token"
                        },
                        icon = Icons.Rounded.Speed,
                        accent = CyanSecondary,
                        modifier = Modifier.weight(1f),
                    )
                    MetricCard(
                        title = "Xotira (RAM)",
                        value = String.format(Locale.US, "%.1f MB", t.ramUsageMb),
                        subtitle = "Byudjet: ${t.ramBudgetMb} / ${t.maxRamCeilingMb} MB",
                        icon = Icons.Rounded.Memory,
                        accent = EmeraldPrimary,
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    MetricCard(
                        title = "Bilimlar grafi (4096-bit)",
                        value = "${t.totalNodes} tugun",
                        subtitle = String.format(
                            Locale.US,
                            "%.1f KB • Siyraklik: %.1f%%",
                            t.brainSizeKb,
                            t.sparsityPercent,
                        ),
                        icon = Icons.Rounded.Storage,
                        accent = AmberTertiary,
                        modifier = Modifier.weight(1f),
                    )
                    MetricCard(
                        title = "POPCNT & Mantiq",
                        value = "${t.totalPopcntOps}",
                        subtitle = "${t.maxAllowedHops}-bosqich • ${t.userRuleCount} yangi",
                        icon = Icons.Rounded.Bolt,
                        accent = EmeraldPrimary,
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            // Dynamic RAM Budget Expansion Panel
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Dinamik xotira byudjeti (${t.ramBudgetMb} / ${t.maxRamCeilingMb} MB)",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                text = "${t.maxAllowedHops}-bosqichli qidiruv",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanSecondary,
                            )
                        }

                        LinearProgressIndicator(
                            progress = { (t.ramBudgetMb.toFloat() / t.maxRamCeilingMb.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = EmeraldPrimary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        )

                        if (t.ramBudgetMb < t.maxRamCeilingMb) {
                            OutlinedButton(
                                onClick = onRequestRamExpansion,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("expand_ram_button"),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.65f)),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Tune,
                                    contentDescription = null,
                                    tint = EmeraldPrimary,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                                Text(
                                    text = "Chuqurroq 4-bosqichli fikrlash (+64 MB RAM so'rash)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = EmeraldPrimary,
                                )
                            }
                        }
                    }
                }
            }

            // Live 16x16 Ternary Gate Weight Matrix Visualizer (-1, 0, +1)
            item {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = stringResource(R.string.monitor_matrix_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                text = "${t.morphemeCorpusCount} morfema",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanSecondary,
                            )
                        }

                        TernaryMatrixCanvas(
                            trits = t.weightSlice256,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp),
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                        ) {
                            LegendItem(color = EmeraldPrimary, label = "+1 (Qo'shish)")
                            LegendItem(color = Color(0xFF283D4D), label = "0 (O'tkazib yuborish)")
                            LegendItem(color = AmberTertiary, label = "-1 (Ayirish)")
                        }
                    }
                }
            }

            // On-Device 5-Prompt Benchmark Runner
            item {
                Button(
                    onClick = onRunBenchmark,
                    enabled = !state.isBenchmarkRunning,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("run_benchmark_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanSecondary,
                        contentColor = MaterialTheme.colorScheme.onSecondary,
                    ),
                ) {
                    if (state.isBenchmarkRunning) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onSecondary,
                        )
                        Spacer(modifier = Modifier.size(10.dp))
                        Text("5 ta mantiqiy sinov bajarilmoqda...")
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "${stringResource(R.string.monitor_benchmark)} (5 ta mantiqiy so'rov)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }

            items(state.benchmarkResults) { item ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = "Savol: ${item.prompt}",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyanSecondary,
                        )
                        Text(
                            text = item.response,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = String.format(
                                Locale.US,
                                "%d token • %.2f ms jami • %.3f ms/tok • Ishonch: %d%% • %d bosqich (%d bekor)",
                                item.tokenCount,
                                item.totalMs,
                                item.msPerToken,
                                item.confidencePct,
                                item.hopsUsed,
                                item.prunedBranches,
                            ),
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(16.dp),
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = accent,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun TernaryMatrixCanvas(
    trits: IntArray,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val cols = 16
        val rows = 16
        val gap = 4.dp.toPx()
        val cellW = (size.width - gap * (cols - 1)) / cols
        val cellH = (size.height - gap * (rows - 1)) / rows

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val idx = r * cols + c
                val trit = if (idx < trits.size) trits[idx] else 0
                val color = when {
                    trit > 0 -> EmeraldPrimary
                    trit < 0 -> AmberTertiary
                    else -> Color(0xFF1D3140)
                }
                drawRoundRect(
                    color = color,
                    topLeft = Offset(c * (cellW + gap), r * (cellH + gap)),
                    size = Size(cellW, cellH),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                )
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
