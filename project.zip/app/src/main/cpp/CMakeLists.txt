cmake_minimum_required(VERSION 3.22.1)
project("tafakkur_ternary")

add_library(
    tafakkur_ternary
    SHARED
    ternary_engine_jni.cpp
)

target_compile_features(tafakkur_ternary PRIVATE cxx_std_17)
target_compile_options(tafakkur_ternary PRIVATE -O3 -Wall)

find_library(log-lib log)
target_link_libraries(tafakkur_ternary ${log-lib})
