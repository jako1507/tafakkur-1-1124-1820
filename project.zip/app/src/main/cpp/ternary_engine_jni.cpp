#include "ternary_brain.h"
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstring>
#include <string>
#include <unordered_set>
#include <vector>

#ifdef __ANDROID__
#include <jni.h>
#endif

namespace tafakkur {

static constexpr size_t HD_BITS = 4096;
static constexpr size_t HD_WORDS = 64;

struct Bitplane4096 {
    uint64_t pos[HD_WORDS] = {0};
    uint64_t neg[HD_WORDS] = {0};

    inline int dot(const Bitplane4096& other) const {
        int posHits = 0;
        int negHits = 0;
        for (size_t w = 0; w < HD_WORDS; ++w) {
            posHits += __builtin_popcountll(pos[w] & other.pos[w]) +
                       __builtin_popcountll(neg[w] & other.neg[w]);
            negHits += __builtin_popcountll(pos[w] & other.neg[w]) +
                       __builtin_popcountll(neg[w] & other.pos[w]);
        }
        return posHits - negHits;
    }

    inline int nonZeroCount() const {
        int nz = 0;
        for (size_t w = 0; w < HD_WORDS; ++w) {
            nz += __builtin_popcountll(pos[w]) + __builtin_popcountll(neg[w]);
        }
        return nz;
    }
};

struct KnowledgeNode {
    int32_t id = 0;
    int32_t nextNodeId = -1;
    int32_t contraGroup = 0;
    int32_t weight = 80;
    std::string domain;
    std::string queryKeys;
    std::string premise;
    std::string mechanism;
    std::string consequence;
    Bitplane4096 hv;
};

struct ReasoningBranch {
    std::vector<int32_t> chainIds;
    int scorePct = 0;
    bool pruned = false;
    std::string pruneReason;
};

static inline uint32_t fnv1a_32(const std::string& s) {
    uint32_t h = 0x811C9DC5u;
    for (unsigned char b : s) {
        h ^= b;
        h *= 0x01000193u;
    }
    return h;
}

class SovereignTernaryEngine {
public:
    Bitplane4096 wGate;
    std::vector<KnowledgeNode> nodes;
    int maxRamBudgetMb = 64;
    static constexpr int MAX_RAM_CEILING_MB = 300;

    bool loadFromEmbedded() {
        const uint8_t* ptr = TAFAKKUR_BRAIN_BIN;
        const size_t total = TAFAKKUR_BRAIN_SIZE;
        if (total < 16 || std::memcmp(ptr, "TFK2", 4) != 0) return false;
        size_t off = 4;

        auto readU32 = [&]() -> uint32_t {
            uint32_t v = 0;
            std::memcpy(&v, ptr + off, 4);
            off += 4;
            return v;
        };
        auto readI32 = [&]() -> int32_t {
            int32_t v = 0;
            std::memcpy(&v, ptr + off, 4);
            off += 4;
            return v;
        };
        auto readU16 = [&]() -> uint16_t {
            uint16_t v = 0;
            std::memcpy(&v, ptr + off, 2);
            off += 2;
            return v;
        };
        auto readU64 = [&]() -> uint64_t {
            uint64_t v = 0;
            std::memcpy(&v, ptr + off, 8);
            off += 8;
            return v;
        };
        auto readStr = [&]() -> std::string {
            uint16_t len = readU16();
            std::string s(reinterpret_cast<const char*>(ptr + off), len);
            off += len;
            return s;
        };

        uint32_t entryCount = readU32();
        uint32_t hdBits = readU32();
        uint32_t hdWords = readU32();
        if (hdBits != HD_BITS || hdWords != HD_WORDS) return false;

        for (size_t w = 0; w < HD_WORDS; ++w) wGate.pos[w] = readU64();
        for (size_t w = 0; w < HD_WORDS; ++w) wGate.neg[w] = readU64();

        nodes.clear();
        nodes.reserve(entryCount);
        for (uint32_t i = 0; i < entryCount; ++i) {
            KnowledgeNode n;
            n.id = static_cast<int32_t>(i);
            n.nextNodeId = readI32();
            n.contraGroup = readI32();
            n.domain = readStr();
            n.queryKeys = readStr();
            n.premise = readStr();
            n.mechanism = readStr();
            n.consequence = readStr();

            uint16_t posCount = readU16();
            uint16_t negCount = readU16();
            for (uint16_t p = 0; p < posCount; ++p) {
                uint16_t idx = readU16();
                if (idx < HD_BITS) n.hv.pos[idx >> 6] |= (1ULL << (idx & 63));
            }
            for (uint16_t ng = 0; ng < negCount; ++ng) {
                uint16_t idx = readU16();
                if (idx < HD_BITS) n.hv.neg[idx >> 6] |= (1ULL << (idx & 63));
            }
            nodes.push_back(std::move(n));
        }
        return true;
    }

    Bitplane4096 encodeFeatures4096(const std::vector<std::string>& features) const {
        int32_t acc[HD_BITS] = {0};
        for (const auto& f : features) {
            uint32_t h = fnv1a_32(f);
            for (int k = 0; k < 6; ++k) {
                uint32_t idx = ((h >> (k * 5)) ^ (static_cast<uint32_t>(k) * 677u)) & (HD_BITS - 1);
                int32_t sign = (((h >> (26 + k)) & 1u) == 0u) ? 1 : -1;
                acc[idx] += sign;
            }
        }
        Bitplane4096 out;
        for (size_t i = 0; i < HD_BITS; ++i) {
            int gate = ((wGate.pos[i >> 6] >> (i & 63)) & 1ULL) ? 1
                     : (((wGate.neg[i >> 6] >> (i & 63)) & 1ULL) ? -1 : 0);
            int prod = acc[i] * gate;
            if (prod > 0) out.pos[i >> 6] |= (1ULL << (i & 63));
            else if (prod < 0) out.neg[i >> 6] |= (1ULL << (i & 63));
        }
        return out;
    }

    int maxAllowedHops() const {
        return (maxRamBudgetMb >= 128) ? 4 : 3;
    }

    bool expandRamBudget() {
        if (maxRamBudgetMb + 64 <= MAX_RAM_CEILING_MB) {
            maxRamBudgetMb += 64;
            return true;
        }
        maxRamBudgetMb = MAX_RAM_CEILING_MB;
        return false;
    }

    size_t pruneLowWeightNodes(int minWeight) {
        size_t before = nodes.size();
        nodes.erase(
            std::remove_if(nodes.begin(), nodes.end(),
                           [&](const KnowledgeNode& n) { return n.weight < minWeight; }),
            nodes.end()
        );
        return before - nodes.size();
    }
};

} // namespace tafakkur

#ifdef __ANDROID__
static tafakkur::SovereignTernaryEngine g_engine;
static bool g_loaded = false;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_engine_NativeTernaryBridge_initNativeBrain(JNIEnv*, jobject) {
    if (!g_loaded) {
        g_loaded = g_engine.loadFromEmbedded();
    }
    return g_loaded ? JNI_TRUE : JNI_FALSE;
}
#endif
