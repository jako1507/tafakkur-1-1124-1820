package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.test.core.app.ApplicationProvider
import com.example.engine.TernaryEngine
import com.example.engine.UzbekMorphology
import com.example.engine.UzbekSyntaxRealizer
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private fun freshEngine(): TernaryEngine {
        val context = ApplicationProvider.getApplicationContext<Context>()
        File(context.filesDir, "user_brain_delta_v2.bin").delete()
        return TernaryEngine(context)
    }

    @Test
    fun `app name uzbek strings and zero internet permission match sovereign spec`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Tafakkur", context.getString(R.string.app_name))
        assertEquals("Suhbat", context.getString(R.string.nav_chat))
        assertEquals("Yangi bilim o'rgatish", context.getString(R.string.nav_train))
        assertEquals("Dvigatel holati", context.getString(R.string.nav_monitor))

        val pkgInfo = context.packageManager.getPackageInfo(
            context.packageName,
            PackageManager.GET_PERMISSIONS,
        )
        val perms = pkgInfo.requestedPermissions?.toList().orEmpty()
        assertFalse("INTERNET permission is strictly forbidden", perms.contains(Manifest.permission.INTERNET))
    }

    @Test
    fun `4096 bit ternary engine runs 5 uzbek reasoning prompts within latency and ram targets`() {
        val engine = freshEngine()

        val telemetryBefore = engine.getTelemetry()
        assertTrue(telemetryBefore.isReady)
        assertTrue("Expected >= 2000 nodes, got ${telemetryBefore.totalNodes}", telemetryBefore.totalNodes >= 2000)
        assertTrue("Expected >= 15000 morphemes, got ${telemetryBefore.morphemeCorpusCount}", telemetryBefore.morphemeCorpusCount >= 15000)
        assertEquals(64, telemetryBefore.ramBudgetMb)
        assertEquals(300, telemetryBefore.maxRamCeilingMb)
        assertEquals(3, telemetryBefore.maxAllowedHops)
        assertTrue(telemetryBefore.ramUsageMb < 300.0)
        assertTrue(telemetryBefore.brainSizeKb > 500.0)

        val results = engine.runUzbekReasoningBenchmark()
        assertEquals(5, results.size)

        println("TEST_PROOF_START")
        println(
            String.format(
                Locale.US,
                "TEST_PROOF_BRAIN: %.2f KB (%.4f MB), Nodes=%d, Morphemes=%d, Sparsity=%.1f%%",
                telemetryBefore.brainSizeKb,
                telemetryBefore.brainSizeKb / 1024.0,
                telemetryBefore.totalNodes,
                telemetryBefore.morphemeCorpusCount,
                telemetryBefore.sparsityPercent,
            )
        )
        for ((idx, item) in results.withIndex()) {
            println("TEST_PROOF_PROMPT_${idx + 1}: ${item.prompt}")
            println("TEST_PROOF_REPLY_${idx + 1}: ${item.response}")
            println(
                String.format(
                    Locale.US,
                    "TEST_PROOF_METRIC_${idx + 1}: %d tokens | %.2f ms | %.3f ms/token | conf=%d%% | hops=%d | pruned=%d",
                    item.tokenCount,
                    item.totalMs,
                    item.msPerToken,
                    item.confidencePct,
                    item.hopsUsed,
                    item.prunedBranches,
                )
            )
            assertTrue("Response should not be blank for: ${item.prompt}", item.response.isNotBlank())
            assertTrue("Confidence should pass 65% gate for: ${item.prompt}", item.confidencePct >= 65)
            assertTrue("Token count should be > 3 for: ${item.prompt}", item.tokenCount > 3)
        }
        val telemetryAfter = engine.getTelemetry()
        println(
            String.format(
                Locale.US,
                "TEST_PROOF_RAM: Usage=%.2f MB / Budget=%d MB (Max=%d MB) | POPCNT ops=%d",
                telemetryAfter.ramUsageMb,
                telemetryAfter.ramBudgetMb,
                telemetryAfter.maxRamCeilingMb,
                telemetryAfter.totalPopcntOps,
            )
        )
        println("TEST_PROOF_END")
        assertTrue(telemetryAfter.ramUsageMb < 300.0)
        assertTrue(telemetryAfter.totalPopcntOps > 0L)
    }

    @Test
    fun `strict below 65 percent refusal gate prevents hallucination`() = runBlocking {
        val engine = freshEngine()

        val nonsenseQueries = listOf(
            "Marsdagi ko'k filning poyabzali necha pul?",
            "zxqv blarg glorp 99182",
        )
        for (query in nonsenseQueries) {
            val chunks = engine.generateStream(query).toList()
            val last = chunks.last()
            assertEquals(
                "Expected exact Uzbek refusal message for unknown query: $query",
                UzbekSyntaxRealizer.REFUSAL_MESSAGE,
                last.partialText,
            )
            assertTrue("Confidence must be < 65% for nonsense query, got ${last.confidencePct}", last.confidencePct < 65)
            assertTrue("Trace steps should explain refusal", last.trace.steps.isNotEmpty())
        }
    }

    @Test
    fun `causal extraction self play deep synthesis feedback and ram expansion work end to end`() = runBlocking {
        val engine = freshEngine()

        // 1. Morphological analyzer handles 45+ suffixes cleanly
        val morph = UzbekMorphology.analyze("Kitoblarimizdan kelgan bilimlarimizga tayanamiz")
        assertTrue(morph.stems.contains("kitob"))
        assertTrue(morph.stems.contains("bilim"))

        // 2. Integer ALU exact arithmetic
        val aluChunks = engine.generateStream("245 + 378").toList()
        val aluFinal = aluChunks.last()
        assertTrue(aluFinal.partialText.contains("623"))
        assertEquals(100, aluFinal.confidencePct)

        // 3. Causal Extraction + Automated Self-Play Loop + Deep Logical Synthesis (A->B + B->C => A->C)
        val rawRules = """
            Agar kvant batareya sovitilsa -> Unda ion harakati barqarorlashadi.
            Agar ion harakati barqarorlashsa -> Unda energiya saqlash sig'imi oshadi.
        """.trimIndent()

        val selfPlay = engine.trainFromTextWithSelfPlay("Kvant batareya", rawRules)
        assertEquals(2, selfPlay.extractedRulesCount)
        assertEquals(2, selfPlay.selfPlayPassed)
        assertTrue(selfPlay.avgConfidencePct >= 65)

        val synthesis = engine.runDeepLogicalSynthesis()
        assertTrue("Expected transitive synthesis link or rule", synthesis.newLinksConnected > 0 || synthesis.newRulesSynthesized > 0)

        val queryChunks = engine.generateStream("Kvant batareya sovitilsa nima bo'ladi?").toList()
        val queryResult = queryChunks.last()
        assertTrue("Answer confidence must pass 65%", queryResult.confidencePct >= 65)
        assertTrue("Reasoning trace must record verified nodes", queryResult.trace.verifiedChainNodeIds.isNotEmpty())
        assertTrue("Multi-hop chain expected >= 2 hops", queryResult.trace.maxHopsUsed >= 2)

        // 4. Real-time reinforcement feedback (👍 / 👎)
        val usedIds = queryResult.trace.verifiedChainNodeIds
        engine.applyFeedback(usedIds, positive = true)
        engine.applyFeedback(usedIds, positive = false)
        assertTrue(engine.getUserNodes().isNotEmpty())

        // 5. Dynamic RAM expansion (64 -> 128 MB unlocks 4-hop reasoning) and pruning
        assertEquals(3, engine.maxAllowedHops())
        val expandedBudget = engine.grantRamExpansion()
        assertEquals(128, expandedBudget)
        assertEquals(4, engine.maxAllowedHops())

        val prunedCount = engine.denyRamExpansionAndPrune()
        assertTrue(prunedCount >= 0)
        assertTrue(engine.getTelemetry().ramBudgetMb <= 300)
    }
}
